import MediaSection from '../MediaSection';

export default function MediaSectionExample() {
  return <MediaSection />;
}
