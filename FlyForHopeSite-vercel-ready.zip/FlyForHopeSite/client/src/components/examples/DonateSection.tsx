import DonateSection from '../DonateSection';

export default function DonateSectionExample() {
  return <DonateSection />;
}
