import SafetySection from '../SafetySection';

export default function SafetySectionExample() {
  return <SafetySection />;
}
